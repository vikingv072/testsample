import Foundation

func flexStrings (_ s1 : String?,_ s2 : String?,_ s3: String?) -> String {
    var comStr: String = ""
    if s1 != nil, s2 != nil, s3 != nil    {
        comStr.append(s1!)
        comStr.append(s2!)
        comStr.append(s3!)
    } else if s2 != nil, s3 != nil {
        comStr.append(s2!)
        comStr.append(s3!)
    } else if s3 != nil {
        comStr.append(s3!)
    } else {comStr = "none" }
    
    return comStr
}

print(flexStrings("hard", "work", "kevin"))
print(flexStrings(nil, "work", "kevin"))
print(flexStrings(nil, nil, "kevin"))
   
        
    

